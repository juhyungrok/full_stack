import React from "react";

const NaverPayment = ({ CartItems, totalprice }) => {
  return <div>네이버페이 </div>;
};
export default NaverPayment;
