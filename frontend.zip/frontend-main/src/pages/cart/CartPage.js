// CartPage.js
import React from "react";

import CartLayout from "../../components/layout/CartLayout";

const CartPage = () => {
  return <CartLayout></CartLayout>;
};

export default CartPage;
