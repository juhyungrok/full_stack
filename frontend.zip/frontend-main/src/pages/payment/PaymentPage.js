import React from "react";
import { Link } from "react-router-dom";

const PaymentPage = () => {
  return <div>결제 완료</div>;
};

export default PaymentPage;
